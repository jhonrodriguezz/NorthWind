﻿//using NorthWind.Sales.Backend.BusinessObjects.Interfaces.CreateOrder;
//using NorthWind.Sales.Backend.Presenters.CreateOrder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Extensions.DependencyInjection;

public static class DependencyContainer
{
    public static IServiceCollection AddPresenters(this IServiceCollection services)
    {
        services.AddScoped<ICreateOrderOutputPort, CreateOrderPresenter>();
        return services;
    }
}
