﻿global using Microsoft.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore.Metadata.Builders;
global using NorthWind.Sales.Backend.BusinessObjects.POCOEntities;
global using Microsoft.Extensions.Options;
global using NorthWind.Sales.Backend.DataContexts.EFCore.Options;
global using NorthWind.Sales.Backend.Repositories.Interfaces;
global using NorthWind.Sales.Backend.DataContexts.EFCore.Services;
global using NorthWind.Sales.Backend.DataContexts.EFCore.DataContexts;