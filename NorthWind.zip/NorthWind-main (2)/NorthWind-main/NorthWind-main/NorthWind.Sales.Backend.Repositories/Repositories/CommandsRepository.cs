﻿//using NorthWind.Sales.Backend.BusinessObjects.Aggregates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using NorthWind.Sales.Backend.Repositories.Interfaces;
//using NorthWind.Sales.Backend.BusinessObjects.Interfaces.Repositories;

namespace NorthWind.Sales.Backend.Repositories.Repositories
{
    internal class CommandsRepository(INorthWindSalesCommandsDataContext context):ICommandsRepository
    {
        public async Task CreateOrder (OrderAggregate order)
        {
            await context.AddOrderAsync (order);
            await context.AddOrderDetailAsync (order.OrderDetails.Select(d=>new Entities.OrderDetail
            {
                Order = order,
                ProductId = d.ProductId,
                Quantity = d.Quantity,
                UnitPrice = d.UnitPrice
            }).ToArray());
        }

        public async Task SaveChanges() => await context.SaveChangesAsync();
    }
}
