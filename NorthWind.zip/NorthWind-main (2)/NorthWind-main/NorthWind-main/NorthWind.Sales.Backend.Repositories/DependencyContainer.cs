﻿//using Microsoft.Extensions.DependencyInjection;
//using NorthWind.Sales.Backend.BusinessObjects.Interfaces.Repositories;
//using NorthWind.Sales.Backend.Repositories.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Extensions.DependencyInjection;

public static class DependencyContainer
{
    public static IServiceCollection AddRepositories(
   this IServiceCollection services)
    {
        services.AddScoped<ICommandsRepository, CommandsRepository>();
        return services;
    }
}
